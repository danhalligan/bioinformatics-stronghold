# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rosalind']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.20.1,<2.0.0', 'requests>=2.25.1,<3.0.0', 'typer>=0.0.8,<0.0.9']

entry_points = \
{'console_scripts': ['rosalind = rosalind.cli:main']}

setup_kwargs = {
    'name': 'rosalind',
    'version': '0.1.0',
    'description': 'Simple (possibly brute force) solutions to the Rosalind problems',
    'long_description': "# Rosalind solver\n\nSolutions to the Rosalind problems in python as a command line app. My solutions\nmay be brute force :relaxed:\n\n<http://rosalind.info/problems/>\n\nI'm trying not to use Biopython (whilst also not attempting to rewrite this from\nscratch!)\n\nSome build details that I'm playing with while putting this together:\n\n- CLI built [using Poetry & Typer]\n- [GitLab CI] based on this [medium blog post]\n- [Black] for code formatting\n- Pre-commit hook for formatting with black using [pre-commit] based on\n  [black docs]\n\n## Install\n\nYou can install with pip:\n\n```bash\ngit clone https://gitlab.fiosgenomics.com/rosalind/dan rosalind-solver\npip3 install rosalind-solver\n```\n\n## Examples\n\n``` bash\nrosalind fibd 80 18\nrosalind perm 3\n```\n\n[using Poetry & Typer]: https://www.pluralsight.com/tech-blog/python-cli-utilities-with-poetry-and-typer/\n[Black]: https://black.readthedocs.io/en/stable/index.html\n[GitLab CI]: https://docs.gitlab.com/ee/ci/\n[medium blog post]: https://medium.com/@paweldudzinski/python-applications-continuous-integration-with-poetry-and-gitlab-pipelines-ac539888251a\n[pre-commit]: https://pre-commit.com/\n[black docs]: https://black.readthedocs.io/en/stable/version_control_integration.html\n",
    'author': 'Daniel Halligan',
    'author_email': 'dan.halligan@fiosgenomics.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
